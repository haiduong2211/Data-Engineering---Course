#!/bin/bash

echo "Enter first number: "
read a
echo "Enter Second Number: "
read b

c=$((a+b))
echo "Sum: $a + $b =  $c"


