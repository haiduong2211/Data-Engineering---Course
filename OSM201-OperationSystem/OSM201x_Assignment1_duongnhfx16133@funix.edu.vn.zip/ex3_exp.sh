#!/bin/bash

Faila=$(cat pre_a_ex3_exp.txt | awk '/FAIL/ {print $2}')
Passa=$(cat pre_a_ex3_exp.txt | awk '/PASS/ {print $2}')
NChecka=$(cat pre_a_ex3_exp.txt | awk '/NOTCHECK/ {print $2}')
Failb=$(cat pre_b_ex3_exp.txt | awk '/FAIL/ {print $2}')
Passb=$(cat pre_b_ex3_exp.txt | awk '/PASS/ {print $2}')
NCheckb=$(cat pre_b_ex3_exp.txt | awk '/NOTCHECK/ {print $2}')
Failc=$(cat pre_c_ex3_exp.txt | awk '/FAIL/ {print $2}')
Passc=$(cat pre_c_ex3_exp.txt | awk '/PASS/ {print $2}')
NCheckc=$(cat pre_c_ex3_exp.txt | awk '/NOTCHECK/ {print $2}')

FAIL=$(($Faila+$Failb+$Failc))
PASS=$(($Passa+$Passb+$Passc))
NOTCHECK=$(($NChecka+$NCheckb+$NCheckc))

sum1=$(($Faila+$Passa+$NChecka))
sum2=$(($Failb+$Passb+$NCheckb))
sum3=$(($Failc+$Passc+$NCheckc))

echo "FAIL: $FAIL" > final_ex3_exp.txt
echo "PASS: $PASS" >> final_ex3_exp.txt
echo "NOTCHECK: $NOTCHECK" >> final_ex3_exp.txt
echo "**********" >> final_ex3_exp.txt
echo "Sum1: $sum1" >> final_ex3_exp.txt
echo "Sum2: $sum2" >> final_ex3_exp.txt
echo "Sum3: $sum3" >> final_ex3_exp.txt


