#!/bin/bash

echo "Who are you? "
read name

if [[ $name = "Hello, I am THE WIND" ]]
then
	echo "Oh guy! Come on!"
elif [[ $name = "Hi, I am THE DEER" ]]
then
	echo "Oh, please show your antler"
elif [[ $name = "Aloha, I am THE RABBIT" ]]
then
	echo "Ahihi, please show me your ear?"
else
	echo "I am sorry, Goodbye!"

fi
